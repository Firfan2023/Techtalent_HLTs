
import java.util.Scanner; // import the Scanner class
public class FizzBuzz {

	public static void main(String[] args) {
	
		Scanner myNumber = new Scanner(System.in); // created a scanner object.
		int userNumber;

		// Enter a number and press Enter
		System.out.println("Enter a number:");
		userNumber = myNumber.nextInt();
		
		for (int i = 1; i <= userNumber; i++) {  //for loop the check the following conditions, starting from 1 to the entered value (userNumber).

		if (i % 3 == 0 && i % 5 == 0) { // conditional statements to check the value of userNumber
			System.out.println("FizzBuzz"); // if the userNumber divisible by 3 and 5 it prints "FizzBuzz" to the console.
		} else if (i % 3 == 0) {
			System.out.println("Fizz"); // if the userNumber only divisible by 3 it prints "Fizz" to the console.
		} else if (i % 5 == 0) {
			System.out.println("Buzz"); // if the userNumber only divisible by 5 it prints "Buzz" to the console
		} else
			System.out.println(i); // otherwise it prints the userNumber to the console.

		}

	}
}

