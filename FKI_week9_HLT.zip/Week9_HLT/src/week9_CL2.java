import java.util.Scanner; // imported the Scanner class to read input from the user.

public class week9_CL2 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.print("Please enter a sentences to check if it's PANGRAM or NOT!: "); // user to enter a sentence.
		String sentence = sc.nextLine().toLowerCase(); // convert the sentence to lower-case.
		boolean[] alphabetCheck = new boolean[26]; // initialised a boolean array called alphabetCheck of length 26 to
													// keep track of which letters of the alphabet are present in the
													// sentence.
		for (char ch : sentence.toCharArray()) { // iterate over each character in the sentence using a for-each loop
			if (Character.isLetter(ch)) { // If the character is a letter, we calculate its index in the alphabetCheck
											// array and set the corresponding element to true.
				int index = ch - 'a';
				alphabetCheck[index] = true;
			}
		}
		boolean isPangram = true; // then iterate over the alphabetCheck array and check if all its elements
									// are true.
		for (boolean b : alphabetCheck) { // If any element is false, it means we haven't seen that letter in the
											// sentence, so we set the isPangram boolean variable to false.
			isPangram = isPangram && b;
		}
		if (isPangram) {
			System.out.println("The sentence is a pangram."); // Finally, printing out whether the sentence is a pangram
																// or not.
		} else {
			System.out.println("The sentence is not a pangram.");
		}
		sc.close();

	}

}
