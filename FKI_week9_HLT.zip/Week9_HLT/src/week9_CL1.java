import java.util.Scanner;

public class week9_CL1 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in); // Scanner object to read user input from the console.
		System.out.print("Enter a sentence: "); // prompts the user to enter a sentence on console.
		String sentence = sc.nextLine(); // created a variable called "sentence", to store user's input.
		String[] words = sentence.split(" "); // Then, split the sentence into an array of words using the split()
												// method with a space character as the delimiter.
		String reversedSentence = ""; // Created an empty string to use for the following for loop conditions then,
										// concatenate for the reversed sentence.

		for (int i = words.length - 1; i >= 0; i--) {
			String word = words[i].replaceAll("[^a-zA-Z]", "").toLowerCase(); // So the way I decided to handle capital
																				// letters and punctuation is by
																				// removing all of them by using
																				// toLowerCase() method and the
																				// replaceAll() method to remove any
																				// non-alphabetic characters from each
																				// word in the sentence, using the
																				// regular expression [^a-zA-Z].
			reversedSentence += word + " "; // so, the for loop through the words in reverse order and concatenate them
											// with a space character to form the reversed sentence.
		}

		System.out.println("Reversed sentence: " + reversedSentence.trim()); // print the reversed sentence to the
																				// console, after removing any leading
																				// or trailing whitespace using the
																				// trim() method.
		sc.close(); // to close the scanner so no more resource leak notification on line 6:)
	}

}
